﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Coverter_with_arrays
{
    public partial class huehuehue2 : Form
    {
        public huehuehue2()
        {
            InitializeComponent();
        }
    }
}
