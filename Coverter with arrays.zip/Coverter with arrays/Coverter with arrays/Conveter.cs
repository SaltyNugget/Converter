﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WMPRichPreviewLauncher;



namespace Coverter_with_arrays
{
    public partial class Conveter : Form
    {
        System.Media.SoundPlayer startSoundPlayer = new System.Media.SoundPlayer(@"C:\Windows\Media\Chord.wav");

        public huehuehue hue = new huehuehue();
        public huehuehue2 hue2 = new huehuehue2();

        public double[] measurements = new double[4]
            {
            //Cm To Inch 
            0.3937,
            //metres to feet
            3.28084,
            //c to f
            32,
            //kilometre to miles
             0.621371,
            };

        public Conveter()
        {
            InitializeComponent();
        }

        //Global Variables and Constants
        double dbl_UofM, dbl_Convert;


        private void btn_Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }

        private void btn_cm_i_Click(object sender, EventArgs e)
        {

            // validate user entry and convert to a double
            if (!double.TryParse(txtcm2inch.Text, out dbl_UofM))
            {
                MessageBox.Show("A numeric must be entered. Please re-enter the value.");
                txtcm2inch.Clear();
                txtcm2inch.Focus();
            }
            else
            {
                dbl_Convert = dbl_UofM * measurements[0];
                txtresults.Text += dbl_Convert.ToString() + " inches" + "\r\n";
            }
        }

        private void btn_m_f_Click(object sender, EventArgs e)
        {
            // validate user entry and convert to a double
            if (!double.TryParse(txtm2f.Text, out dbl_UofM))
            {
                MessageBox.Show("A numeric must be entered. Please re-enter the value.");
                txtm2f.Clear();
                txtm2f.Focus();
            }
            else
            {
                dbl_Convert = dbl_UofM * measurements[1];
                txtresults.Text += dbl_Convert.ToString() + " Feet" + "\r\n";
            }
        }

        private void btn_c_f_Click(object sender, EventArgs e)
        {
            // validate user entry and convert to a double
            if (!double.TryParse(txtc2f.Text, out dbl_UofM))
            {
                MessageBox.Show("A numeric must be entered. Please re-enter the value.");
                txtc2f.Clear();
                txtc2f.Focus();
            }
            else
            {
                dbl_Convert = (((dbl_UofM *9)/5) + measurements[2]);
                txtresults.Text += dbl_Convert.ToString() + " Fahrenheit" + "\r\n";
            }
        }

        private void btn_k_m_Click(object sender, EventArgs e)
        {
            // validate user entry and convert to a double
            if (!double.TryParse(txtk2m.Text, out dbl_UofM))
            {
                MessageBox.Show("A numeric must be entered. Please re-enter the value.");
                txtk2m.Clear();
                txtk2m.Focus();
            }
            else
            {
                dbl_Convert = dbl_UofM * measurements[3];
                txtresults.Text += dbl_Convert.ToString() + " Miles" + "\r\n";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtcm2inch.Clear();
            txtm2f.Clear();
            txtc2f.Clear();
            txtk2m.Clear();
            txtresults.Clear();
            
        }

        //A little fun to kill time with by showing form and plaing windows sound.
        private void button2_Click(object sender, EventArgs e)
        {
            while (true)
            {
                hue.Show();
                System.Threading.Thread.Sleep(400);
                hue.Hide();
                System.Threading.Thread.Sleep(200);
                hue.Show();
                hue2.Show();
                System.Threading.Thread.Sleep(400);
                hue2.Hide();
                System.Threading.Thread.Sleep(200);
                hue2.Show();
                System.Threading.Thread.Sleep(10);
                startSoundPlayer.Play();
            }

        }

        // Button will convert all the measurements in the text boxes
        private void btnAll_Click(object sender, EventArgs e)
        {
            float  ADD = 99999999;
            if (!string.IsNullOrEmpty(txtcm2inch.Text + txtk2m.Text + txtm2f.Text + txtc2f.Text))
            {
                if (!float.TryParse(txtcm2inch.Text + txtc2f.Text + txtk2m.Text + txtm2f.Text, out ADD))
                {
                    MessageBox.Show("Input vaild values","Error",MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    try
                    {
                        txtresults.Text += ("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" + "\r\n");
                        dbl_Convert = (float.Parse(txtcm2inch.Text) * measurements[0]);
                        txtresults.Text += dbl_Convert.ToString() + " Inches" + "\r\n";

                        dbl_Convert = ((float.Parse(txtm2f.Text) * measurements[1]));
                        txtresults.Text += dbl_Convert.ToString() + " Feet" + "\r\n";

                        dbl_Convert = ((float.Parse(txtc2f.Text) * 9) / 5) + measurements[2];
                        txtresults.Text += dbl_Convert.ToString() + " Fahrenheit" + "\r\n";

                        dbl_Convert = ((float.Parse(txtk2m.Text) * measurements[0]));
                        txtresults.Text += dbl_Convert.ToString() + " Miles" + "\r\n";
                        txtresults.Text += ("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" + "\r\n");
                    }
                    catch(Exception ex)
                    {

                    }
                }
            }
            else
            {
                MessageBox.Show("Fill All Fields with values","Error",MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }



        //Teach the user to not press random buttons, loops message "Hello"
        private void btn_hehe_Click(object sender, EventArgs e)
        {
            while (true)
            {
                MessageBox.Show("Hello", "Why", MessageBoxButtons.OK, MessageBoxIcon.Stop);  
            }

        }
    }

}
