﻿namespace Coverter_with_arrays
{
    partial class Conveter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_cm_i = new System.Windows.Forms.Button();
            this.btn_m_f = new System.Windows.Forms.Button();
            this.btn_c_f = new System.Windows.Forms.Button();
            this.btn_k_m = new System.Windows.Forms.Button();
            this.btn_Exit = new System.Windows.Forms.Button();
            this.txtcm2inch = new System.Windows.Forms.TextBox();
            this.txtm2f = new System.Windows.Forms.TextBox();
            this.txtc2f = new System.Windows.Forms.TextBox();
            this.txtk2m = new System.Windows.Forms.TextBox();
            this.txtresults = new System.Windows.Forms.RichTextBox();
            this.lb_Converter = new System.Windows.Forms.Label();
            this.btn_hehe = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnAll = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_cm_i
            // 
            this.btn_cm_i.ForeColor = System.Drawing.Color.Black;
            this.btn_cm_i.Location = new System.Drawing.Point(141, 72);
            this.btn_cm_i.Name = "btn_cm_i";
            this.btn_cm_i.Size = new System.Drawing.Size(191, 23);
            this.btn_cm_i.TabIndex = 0;
            this.btn_cm_i.Text = "Centimetre To Inches";
            this.btn_cm_i.UseVisualStyleBackColor = true;
            this.btn_cm_i.Click += new System.EventHandler(this.btn_cm_i_Click);
            // 
            // btn_m_f
            // 
            this.btn_m_f.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_m_f.Location = new System.Drawing.Point(141, 111);
            this.btn_m_f.Name = "btn_m_f";
            this.btn_m_f.Size = new System.Drawing.Size(191, 23);
            this.btn_m_f.TabIndex = 1;
            this.btn_m_f.Text = "Metres To Feet";
            this.btn_m_f.UseVisualStyleBackColor = true;
            this.btn_m_f.Click += new System.EventHandler(this.btn_m_f_Click);
            // 
            // btn_c_f
            // 
            this.btn_c_f.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_c_f.Location = new System.Drawing.Point(141, 150);
            this.btn_c_f.Name = "btn_c_f";
            this.btn_c_f.Size = new System.Drawing.Size(191, 23);
            this.btn_c_f.TabIndex = 2;
            this.btn_c_f.Text = "Celsius To Fahrenheit";
            this.btn_c_f.UseVisualStyleBackColor = true;
            this.btn_c_f.Click += new System.EventHandler(this.btn_c_f_Click);
            // 
            // btn_k_m
            // 
            this.btn_k_m.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_k_m.Location = new System.Drawing.Point(141, 192);
            this.btn_k_m.Name = "btn_k_m";
            this.btn_k_m.Size = new System.Drawing.Size(191, 23);
            this.btn_k_m.TabIndex = 3;
            this.btn_k_m.Text = "Kilometers to Miles";
            this.btn_k_m.UseVisualStyleBackColor = true;
            this.btn_k_m.Click += new System.EventHandler(this.btn_k_m_Click);
            // 
            // btn_Exit
            // 
            this.btn_Exit.Location = new System.Drawing.Point(257, 504);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(75, 23);
            this.btn_Exit.TabIndex = 5;
            this.btn_Exit.Text = "Exit";
            this.btn_Exit.UseVisualStyleBackColor = true;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
            // 
            // txtcm2inch
            // 
            this.txtcm2inch.Location = new System.Drawing.Point(15, 74);
            this.txtcm2inch.Name = "txtcm2inch";
            this.txtcm2inch.Size = new System.Drawing.Size(100, 20);
            this.txtcm2inch.TabIndex = 6;
            // 
            // txtm2f
            // 
            this.txtm2f.Location = new System.Drawing.Point(15, 114);
            this.txtm2f.Name = "txtm2f";
            this.txtm2f.Size = new System.Drawing.Size(100, 20);
            this.txtm2f.TabIndex = 7;
            // 
            // txtc2f
            // 
            this.txtc2f.Location = new System.Drawing.Point(15, 153);
            this.txtc2f.Name = "txtc2f";
            this.txtc2f.Size = new System.Drawing.Size(100, 20);
            this.txtc2f.TabIndex = 8;
            // 
            // txtk2m
            // 
            this.txtk2m.Location = new System.Drawing.Point(15, 195);
            this.txtk2m.Name = "txtk2m";
            this.txtk2m.Size = new System.Drawing.Size(100, 20);
            this.txtk2m.TabIndex = 9;
            // 
            // txtresults
            // 
            this.txtresults.BackColor = System.Drawing.SystemColors.Window;
            this.txtresults.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtresults.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtresults.Location = new System.Drawing.Point(15, 252);
            this.txtresults.Name = "txtresults";
            this.txtresults.ReadOnly = true;
            this.txtresults.Size = new System.Drawing.Size(307, 246);
            this.txtresults.TabIndex = 10;
            this.txtresults.Text = "";
            // 
            // lb_Converter
            // 
            this.lb_Converter.AutoSize = true;
            this.lb_Converter.BackColor = System.Drawing.Color.Transparent;
            this.lb_Converter.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Converter.ForeColor = System.Drawing.Color.Black;
            this.lb_Converter.Location = new System.Drawing.Point(12, 13);
            this.lb_Converter.Name = "lb_Converter";
            this.lb_Converter.Size = new System.Drawing.Size(166, 39);
            this.lb_Converter.TabIndex = 11;
            this.lb_Converter.Text = "Converter";
            // 
            // btn_hehe
            // 
            this.btn_hehe.Location = new System.Drawing.Point(12, 517);
            this.btn_hehe.Name = "btn_hehe";
            this.btn_hehe.Size = new System.Drawing.Size(10, 10);
            this.btn_hehe.TabIndex = 12;
            this.btn_hehe.Text = "Exit";
            this.btn_hehe.UseVisualStyleBackColor = true;
            this.btn_hehe.Click += new System.EventHandler(this.btn_hehe_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(176, 223);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 13;
            this.button1.Text = "Clear";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(28, 517);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(10, 10);
            this.button2.TabIndex = 14;
            this.button2.Text = "Fun";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnAll
            // 
            this.btnAll.Location = new System.Drawing.Point(257, 223);
            this.btnAll.Name = "btnAll";
            this.btnAll.Size = new System.Drawing.Size(75, 23);
            this.btnAll.TabIndex = 15;
            this.btnAll.Text = "All";
            this.btnAll.UseVisualStyleBackColor = true;
            this.btnAll.Click += new System.EventHandler(this.btnAll_Click);
            // 
            // Conveter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Coverter_with_arrays.Properties.Resources._3f5a00acf72df93528b6bb7cd0a4fd0c;
            this.ClientSize = new System.Drawing.Size(334, 533);
            this.Controls.Add(this.btnAll);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btn_hehe);
            this.Controls.Add(this.lb_Converter);
            this.Controls.Add(this.txtresults);
            this.Controls.Add(this.txtk2m);
            this.Controls.Add(this.txtc2f);
            this.Controls.Add(this.txtm2f);
            this.Controls.Add(this.txtcm2inch);
            this.Controls.Add(this.btn_Exit);
            this.Controls.Add(this.btn_k_m);
            this.Controls.Add(this.btn_c_f);
            this.Controls.Add(this.btn_m_f);
            this.Controls.Add(this.btn_cm_i);
            this.Name = "Conveter";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_cm_i;
        private System.Windows.Forms.Button btn_m_f;
        private System.Windows.Forms.Button btn_c_f;
        private System.Windows.Forms.Button btn_k_m;
        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.TextBox txtcm2inch;
        private System.Windows.Forms.TextBox txtm2f;
        private System.Windows.Forms.TextBox txtc2f;
        private System.Windows.Forms.TextBox txtk2m;
        private System.Windows.Forms.RichTextBox txtresults;
        private System.Windows.Forms.Label lb_Converter;
        private System.Windows.Forms.Button btn_hehe;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnAll;
    }
}

